export default function SlidingBar() {
    return (
      <div className="overflow-hidden bg-black text-white py-3 rounded-b-2xl">
        <div className="marquee text-lg font-bold">
          🚚 Free Shipping on All Orders! 🚚 Free Shipping on All Orders! 🚚 Free Shipping on All Orders! 🚚 Free Shipping on All Orders!
        </div>
      </div>
    );
  }
  