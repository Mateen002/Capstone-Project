export default function About() {
    return(
        <>
        <div className=" flex flex-col  mx-auto  p-8 space-y-7 ">
        
            <div className="max-w-8xl bg-blue-300 flex flex-col text-center h-auto  py-10 md:py-35 px-10 md:px-30 rounded-2xl">
                
                    <h1 className="text-3xl md:text-5xl font-bold mb-4">our story</h1>
                    <p className=" text-lg md:text-3xl mb-10">Lorem, ipsum dolor sit ame ccusamus dolor veritatis, deleniti quae quasi itaque quam? Quidem, dolores. adipisicing elit. Eligendi, quos. Lorem ipsum dolor sit amet.</p>
                    <p className="text-sm ">for every body, anywhere</p>
            </div>
            
        </div>
        </>
    )
}