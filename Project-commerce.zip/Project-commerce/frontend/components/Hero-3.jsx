import { useEffect, useRef, useState } from "react";
import Card_2 from "../cards/Card-hero2";

    export default function Hero_3() {
        const carouselRef = useRef(null);
        const [isMobile, setIsMobile] = useState(false);
        const slideDuration = 3000; // 3 seconds interval
    
        useEffect(() => {
            const checkScreenSize = () => {
                const width = window.innerWidth;
                const height = window.innerHeight;
                setIsMobile(width < 768 && height > width); // Auto-slide only on portrait mobile
            };
    
            checkScreenSize();
            window.addEventListener("resize", checkScreenSize);
            
            return () => window.removeEventListener("resize", checkScreenSize);
        }, []);
    
        useEffect(() => {
            if (!isMobile || !carouselRef.current) return;
    
            const scrollContainer = carouselRef.current;
            const items = scrollContainer.children;
            let index = 0;
    
            const interval = setInterval(() => {
                index = (index + 1) % items.length; // Move to the next item (loop back at the end)
                const nextItem = items[index];
                scrollContainer.scrollTo({
                    left: nextItem.offsetLeft,
                    behavior: "smooth",
                });
            }, slideDuration);
    
            return () => clearInterval(interval);
        }, [isMobile]);
    


    return(
        <>
        <div className="  mx-auto max-w-8xl px-8 rounded-lg mt-10 mb-10 ">
            <h1 className="text-4xl font-semibold my-10">best Sellers</h1>
            <div
            
             ref={carouselRef}

            className="flex w-full  md:max-w-auto md:flex  overflow-scroll md:overflow-hidden items-center mx-auto space-x-3  scrollbar-hide snap-x snap-mandatory">

               <Card_2
               img="1.png"
               />  
               <Card_2
               img="2.png"
               />
               <Card_2
               img="3.png"
               />
               <Card_2
               img="4.png"
               />         
              
               </div>
        </div>
        </>
    )
}