import Card_cat from "../cards/Card-cat";

export default function Hero_cat() {
  return (
    <>
      <div className="  flex flex-col  mx-auto max-w-7xl p-8 space-y-7   ">
        <div className="flex justify-between">
          <div className="font-medium">
            <h1 className=" text-2xl md:text-4xl">shop by category</h1>
          </div>
          <div>
          <button className="border py-1 px-10 text-lg md:py-2 md:px-12 md:text-2xl rounded-lg">shop now</button>
          </div>
        </div>

        <div className="flex flex-col space-y-10  space-x-3 md:flex md:flex-row ">
        <Card_cat 
        bg={"hover:bg-blue-300"}
        img={"https://peachmart.pk/wp-content/uploads/2024/01/s-287black-2.jpeg"}
        text={"Sunglasses"}
        />
        <Card_cat
        bg={"hover:bg-amber-300"}
        img={"eyewear.png"}
        text={"eyewear"}
        />
        <Card_cat
        bg={"hover:bg-amber-600"}
        img={"https://eyelens.pk/cdn/shop/files/eyelens-hazel.jpg?v=1711351137"}
        text={"lens "}

        />
        

        </div>
      </div>
    </>
  );
}
