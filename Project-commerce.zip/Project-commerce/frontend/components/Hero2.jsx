export default function Hero_1(props) {
    return (
        <div className="mx-auto   max-w-6xl rounded-2xl ">
            <div 
                className="bg-[url('/hero1.avif')] bg-cover  bg-center h-[500px] rounded-2xl"
            >
                {/* Optional: Add content inside */}
                <div className="flex  items-end  justify-left h-full text-white text-3xl font-bold">
                    <div className="p-8">
                    <h1 className="font-bold">Discover</h1>
                    <button className= "py-1.5 px-3 border rounded-2xl hover:bg-white hover:text-black">Shop Now</button>
                    </div>
                </div>

            </div>
        </div>
    );
}
