import SlidingBar from "./SlidingBar";

export default function Hero_1(props) {
    return (
        <div 
        style={{position: `${props.position }`}}
        className="mx-auto  max-w-8xl px-8 rounded-2xl my-10">
            <div 
className={`bg-cover bg-no-repeat bg-center h-[500px] ${props.radius}`}
style={{ backgroundImage: `url(${props.bg})` }}

            >
                {/* Optional: Add content inside */}
                <div className="flex  items-end  justify-left h-full text-white  ">
                    <div className=" space-y-2 p-8">
                    <h1 className="text-5xl font-bold">{props.heading}    
                    </h1>
                    <p className="text-3xl">{props.para}</p>
                    <button className= "py-1.5 px-3 border rounded-2xl hover:bg-white hover:text-black">Shop Now</button>
                    </div>

                    
                </div>
                
            </div>
            {props.is ? <SlidingBar/> : false}
        </div>
    );
}
