// import { useState } from "react"
// export default function NavBar() {
//     const [isNav,setIsNav] = useState(false)
//     return(
//         <>
//         <nav className="bg-black   flex items-center max-w-auto justify-between  text-white m-8 rounded-4xl p-3  sticky top-5 left-0 z-50 shadow-md">
//             <div className="flex space-x-10 ml-10">
//             <h1 className="text-lg">Eyewear</h1>
//                     <div className="hidden md:flex"><ul className=" items-center md:flex ml-10 space-x-10">
//                     <li>Home</li>
//                     <li>Products</li>
//                     <li>About</li>
//                 </ul></div>
//             </div>
//             {/* Mobile Menu Button */}
//             <div className="md:hidden">
//                     <button onClick={() => setIsNav(!isNav)}>
//                         {isNav ? "X" : "☰"}
//                     </button>
//                 </div>

//            {/* Right Side - Login & Search */}
//            <div className="hidden md:flex items-center space-x-10">
//                    <ul className="flex items-center space-x-2.5"> <li>Login</li>
//                     <li>
//                         <input 
//                             placeholder="Search"
//                             className="border py-0.5 px-1.5 rounded-2xl"
//                             type="text"  
//                         />
//                     </li></ul>
//                 </div>
            
//         </nav>
//         {/* Mobile Menu */}
//         {isNav && (
//                 <div className="md:hidden bg-black text-white p-3 rounded-b-3xl">
//                     <ul className="flex flex-col items-center space-y-3">
//                         <li>Home</li>
//                         <li>Products</li>
//                         <li>About</li>
//                         <li>Login</li>
//                         <li>
//                             <input 
//                                 placeholder="Search"
//                                 className="border py-0.5 px-1.5 rounded-2xl"
//                                 type="text"  
//                             />
//                         </li>
//                     </ul>
//                 </div>
//             )}
//         </>
//     )
// }