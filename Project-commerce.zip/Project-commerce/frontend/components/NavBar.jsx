import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function NavBar() {
  const [isNav, setIsNav] = useState(false);
  const [showNav, setShowNav] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false); // Track login status
  const navigate = useNavigate();

  let lastScrollY = window.scrollY;

  // Check if the user is logged in on component mount
  useEffect(() => {
    const token = localStorage.getItem("access_token");
    console.log("Token:", token); // Debugging: Log the token
    setIsLoggedIn(!!token); // Set isLoggedIn to true if token exists
  }, []);

  // Handle scroll to show/hide navbar
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > lastScrollY) {
        setShowNav(false); // Hide on scroll down
      } else {
        setShowNav(true); // Show on scroll up
      }
      lastScrollY = window.scrollY;
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Handle logout
  const handleLogout = () => {
    localStorage.removeItem("access_token"); // Clear the token
    localStorage.removeItem("user"); // Clear the user data (if stored)
    setIsLoggedIn(false); // Update login status
    navigate("/login"); // Redirect to the login page
  };

  // Handle Add Product button click
  const handleAddProduct = () => {
    if (isLoggedIn) {
      navigate("/add-product"); // Redirect to the add product page
    } else {
      navigate("/login"); // Redirect to the login page
    }
  };

  return (
    <>
      <nav
        className={`bg-black flex items-center max-w-auto justify-between text-white m-8 rounded-4xl p-3 sticky top-0 left-0 z-50 shadow-md transition-all duration-300 ${
          showNav ? "translate-y-0" : "-translate-y-full"
        }`}
      >
        <div className="flex space-x-10 ml-10">
          <h1 className="text-lg">Eyewear</h1>
          <div className="hidden md:flex">
            <ul className="items-center md:flex ml-10 space-x-10">
              <li>
                <Link to="/">Home</Link>
              </li>
              <li>
                <Link to="/products">Products</Link>
              </li>
              <li>
                <Link to="/about">About</Link>
              </li>
              <li>
                <Link to="/cart">Cart</Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <button onClick={() => setIsNav(!isNav)}>
            {isNav ? "X" : "☰"}
          </button>
        </div>

        {/* Right Side - Login, Search, and Logout */}
        <div className="hidden md:flex items-center space-x-10">
          <ul className="flex items-center space-x-2.5">
            {/* Show Add Product button if logged in */}
            {isLoggedIn && (
              <li>
                <button onClick={handleAddProduct}>Add Product</button>
              </li>
            )}

            {/* Show Login or Logout based on login status */}
            {!isLoggedIn ? (
              <li>
                <Link to="/login">Login</Link>
              </li>
            ) : (
              <li>
                <button onClick={handleLogout}>Logout</button>
              </li>
            )}

            <li>
              <input
                placeholder="Search"
                className="border py-0.5 px-1.5 rounded-2xl"
                type="text"
              />
            </li>
          </ul>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isNav && (
        <div className="md:hidden bg-black text-white p-3 rounded-b-3xl">
          <ul className="flex flex-col items-center space-y-3">
            <li>Home</li>
            <li>Products</li>
            <li>About</li>
            {/* Show Login or Logout based on login status */}
            {!isLoggedIn ? (
              <li>
                <Link to="/login">Login</Link>
              </li>
            ) : (
              <li>
                <button className="cursor-pointer" onClick={handleLogout}>
                  Logout
                </button>
              </li>
            )}
            <li>
              <input
                placeholder="Search"
                className="border py-0.5 px-1.5 rounded-2xl"
                type="text"
              />
            </li>
          </ul>
        </div>
      )}
    </>
  );
}