export default function Footer() {
    return (
      <footer className="max-w-8xl mx-auto text-white bg-green-800 p-10">
        <div className="flex flex-col space-y-35">
          {/* Main Footer Sections */}
          <div className="flex flex-col md:flex-row justify-between">
            {/* Links Section */}
            <div className="flex flex-wrap gap-10 md:gap-20 font-extralight">
              {/* Shop Section */}
              <div className="flex flex-col">
                <h1 className="mb-5 font-bold">Shop</h1>
                <ul className="space-y-1">
                  <li>Home</li>
                  <li>About</li>
                  <li>Shop</li>
                  <li>Blog</li>
                </ul>
              </div>
  
              {/* Policy Section */}
              <div className="flex flex-col">
                <h1 className="mb-5 font-bold">Policy</h1>
                <ul className="space-y-1">
                  <li>Terms & Conditions</li>
                  <li>Privacy Policy</li>
                  <li>Refund Policy</li>
                  <li>Shipping Policy</li>
                  <li>Accessibility</li>
                  <li>Statement</li>
                </ul>
              </div>
  
              {/* Contact Section */}
              <div className="flex flex-col">
                <h1 className="mb-5 font-bold">Contact</h1>
                <ul className="space-y-1">
                  <li>500 Terry Francine Street</li>
                  <li>San Francisco, CA 94158</li>
                  <li>info@mysite.com</li>
                  <li>123-456-7890</li>
                </ul>
              </div>
            </div>
  
            {/* Newsletter Subscription */}
            <div className="md:w-1/2 space-y-5 mt-10 md:mt-0">
              <h1 className="text-3xl md:text-4xl font-semibold">
                Subscribe to Our Newsletter
              </h1>
              <p className="text-lg">
                Be the first to know about our hottest discounts.
              </p>
              <label htmlFor="email" className="text-sm">
                Email *
              </label>
              <input
                className="border w-full p-3 rounded-md text-white"
                type="email"
                id="email"
                placeholder="Your email"
              />
              <div className="flex justify-between items-center">
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="subscribe" />
                  <label htmlFor="subscribe" className="text-sm">
                    Yes, Subscribe
                  </label>
                </div>
                <button className="bg-green-500 text-white px-6 py-3 rounded-md hover:bg-green-600">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
  
          {/* Footer Bottom Section */}
          <div className="flex flex-col md:flex-row justify-between items-center border-t pt-5 text-center md:text-left">
            <h1 className="text-2xl font-bold">Onsko</h1>
            <p className="text-sm">© 2035 by Onsko. Made with Wix Studio</p>
          </div>
        </div>
      </footer>
    );
  }
  