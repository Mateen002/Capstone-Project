import { useEffect, useState } from "react";

export default function Social() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const section = document.getElementById("social-section");
      if (section) {
        const rect = section.getBoundingClientRect();
        const windowHeight = window.innerHeight || document.documentElement.clientHeight;

        // Adjust visibility threshold for smaller screens
        if (rect.top < windowHeight * 0.85) {
          setIsVisible(true);
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    handleScroll(); // Run once on mount in case the section is already in view

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div
      id="social-section"
      className={`p-2 mb-5 space-y-1 md:space-y-5 mx-auto max-w-6xl flex flex-col items-center justify-center text-center 
      transition-all duration-1000 ease-out transform ${
        isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-20"
      }`}
    >
      <div>
        <img className="h-10" src="insta.png " alt="" />
      </div>
      <div>
        <h1 className="text-xl md:text-5xl font-bold">Follow us on Instagram</h1>
      </div>
      <div>
        <p className="text-md md:text-2xl">#unique_eyewear1</p>
      </div>
    </div>
  );
}
