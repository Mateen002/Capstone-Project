import { useState } from 'react'

import Navbar from '../components/NavBar'
import Hero_1 from '../components/Hero1'
import Hero2 from '../components/Hero2'
import Hero_3 from '../components/Hero-3'
import SlidingBar from '../components/SlidingBar'
import Hero_cat from '../components/Hero_cat'
import About from '../components/About'
import Social from '../components/Social'
import Footer from '../components/Footer'
import Products from '../pages/Products'
export default function Home() {
    return(
        <>
        <Hero_1 
    radius = "rounded-2xl"
    heading={<> 
    shine on
    </>}
    bg="/chashmay.webp"/>
    {/* <Hero2/> */}
    <Hero_3/>
    <Hero_1
    radius = "rounded-t-2xl"
            heading={
                <>
                    efforts beauty,
                    <br />
                    timeless charm
                </>
            }
            bg="/hero2.jpg"
            position="sticky"
            para = "new arrivals now in stock"
            is = "true"
        />

        <Hero_cat/>
        <About/>
       <Social/>
        </>
    )
}