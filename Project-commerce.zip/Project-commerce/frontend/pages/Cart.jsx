import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function Cart() {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [checkoutLoading, setCheckoutLoading] = useState(false);
  const navigate = useNavigate();

  // Fetch cart items from the backend
  useEffect(() => {
    const fetchCartItems = async () => {
      try {
        const token = localStorage.getItem("access_token"); // Get the JWT token
        if (!token) {
          navigate("/login"); // Redirect to login page if the user is not authenticated
          return;
        }

        const response = await fetch("http://localhost:8000/api/cart/", {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the request
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch cart items");
        }

        const data = await response.json();
        console.log("Cart Items:", data); // Log the cart items
        setCartItems(data); // Set the cart items
      } catch (error) {
        console.error("Error fetching cart items:", error);
        setError("Failed to load cart items");
      } finally {
        setLoading(false);
      }
    };

    fetchCartItems();
  }, [navigate]);

  // Handle quantity increment and decrement
  const handleQuantityChange = async (itemId, newQuantity) => {
    try {
      const token = localStorage.getItem("access_token"); // Get the JWT token
      if (!token) {
        navigate("/login"); // Redirect to login page if the user is not authenticated
        return;
      }

      // Ensure the quantity is at least 1
      if (newQuantity < 1) {
        newQuantity = 1;
      }

      // Update the quantity in the backend
      const response = await fetch(`http://localhost:8000/api/cart/${itemId}/`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`, // Include the token in the request
        },
        body: JSON.stringify({ quantity: newQuantity }),
      });

      if (!response.ok) {
        throw new Error("Failed to update quantity");
      }

      // Update the quantity in the frontend state
      setCartItems((prevItems) =>
        prevItems.map((item) =>
          item.id === itemId ? { ...item, quantity: newQuantity } : item
        )
      );
    } catch (error) {
      console.error("Error updating quantity:", error);
      setError("Failed to update quantity");
    }
  };

  // Handle deleting an item from the cart
  const handleDeleteItem = async (itemId) => {
    try {
      const token = localStorage.getItem("access_token"); // Get the JWT token
      const response = await fetch(`http://localhost:8000/api/cart/${itemId}/`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the request
        },
      });

      if (!response.ok) {
        throw new Error("Failed to delete item");
      }

      // Remove the item from the cart items state
      setCartItems((prevItems) => prevItems.filter((item) => item.id !== itemId));
    } catch (error) {
      console.error("Error deleting item:", error);
      setError("Failed to delete item");
    }
  };

  // Handle checkout
  const handleCheckout = async () => {
    try {
      const token = localStorage.getItem("access_token"); // Get the JWT token
      if (!token) {
        navigate("/login"); // Redirect to login page if the user is not authenticated
        return;
      }
  
      setCheckoutLoading(true); // Show loading state during checkout
  
      const totalPrice = calculateTotal(); // Calculate the total price
      const response = await fetch("http://localhost:8000/api/checkout/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`, // Include the token in the request
        },
        body: JSON.stringify({
          total_price: totalPrice, // Add total_price to the payload
          shipping_address: "123 Main St, Punjab, Pakistan", // Replace with actual data
          payment_method: "Credit Card", // Replace with actual data
        }),
      });
  
      if (!response.ok) {
        throw new Error("Failed to checkout");
      }
  
      const data = await response.json();
      navigate("/checkout", { state: { orderId: data.order_id } }); // Redirect to the checkout page with order ID
    } catch (error) {
      console.error("Error during checkout:", error);
      setError("Failed to checkout");
    } finally {
      setCheckoutLoading(false); // Hide loading state
    }
  };

  // Calculate the total price of all items in the cart
  const calculateTotal = () => {
    return cartItems
      .reduce((total, item) => {
        const price = parseFloat(item.product_details?.price || 0); // Use product_details
        const quantity = parseInt(item.quantity || 0); // Ensure quantity is a number
        return total + price * quantity;
      }, 0)
      .toFixed(2);
  };

  if (loading) {
    return <div className="text-center py-10">Loading...</div>; // Show a loading state while fetching data
  }

  if (error) {
    return <div className="text-center py-10 text-red-500">Error: {error}</div>; // Show an error message if something went wrong
  }

  return (
    <div className="mx-auto max-w-7xl mb-10 px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Cart Section - Takes 3/4 of the screen on medium+ screens */}
        <div className="w-full md:w-3/4">
          <h1 className="text-2xl font-bold mb-6">My Cart</h1>
          {cartItems.length === 0 ? (
            <p className="text-gray-600">Your cart is empty.</p>
          ) : (
            <div className="space-y-6">
              {cartItems.map((item) => (
                <div
                  key={item.id}
                  className="border p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="flex flex-col md:flex-row gap-6">
                    {/* Product Image */}
                    <img
                      src={
                        item.product_details?.image
                          ? `http://localhost:8000${item.product_details.image}`
                          : "/1.webp"
                      }
                      className="w-24 h-24 md:w-32 md:h-32 object-cover rounded-lg"
                      alt={item.product_details?.name || "Product"}
                    />

                    {/* Product Info */}
                    <div className="flex-1">
                      <h2 className="text-xl font-semibold">
                        {item.product_details?.name || "Product Name Not Available"}
                      </h2>
                      <p className="text-gray-600">${item.product_details?.price || "0.00"}</p>

                      {/* Quantity Controls */}
                      <div className="mt-4 flex items-center gap-4">
                        <div className="flex items-center border rounded-lg">
                          <button
                            onClick={() =>
                              handleQuantityChange(item.id, item.quantity - 1)
                            }
                            className="px-3 py-1 bg-gray-100 hover:bg-gray-200 rounded-l-lg"
                          >
                            -
                          </button>
                          <p className="px-4 py-1 text-lg font-medium">
                            {item.quantity}
                          </p>
                          <button
                            onClick={() =>
                              handleQuantityChange(item.id, item.quantity + 1)
                            }
                            className="px-3 py-1 bg-gray-100 hover:bg-gray-200 rounded-r-lg"
                          >
                            +
                          </button>
                        </div>
                        <p className="text-lg font-semibold">
                          ${(parseFloat(item.product_details?.price || 0) * item.quantity).toFixed(2)}
                        </p>
                      </div>
                    </div>

                    {/* Delete Button */}
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="text-red-500 hover:text-red-700 self-start md:self-center"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Promo Code and Note */}
          <div className="mt-8 space-y-4">
            <div className="flex items-center gap-4">
              <input
                type="text"
                placeholder="Enter a promo code"
                className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">
                Apply
              </button>
            </div>
            <textarea
              placeholder="Add a note"
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows="3"
            />
          </div>
        </div>

        {/* Order Summary - Takes 1/4 of the screen on medium+ screens */}
        <div className="w-full md:w-1/4">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h1 className="text-2xl font-bold mb-6">Order Summary</h1>
            <div className="space-y-4">
              <div className="flex justify-between">
                <p className="text-gray-600">Subtotal</p>
                <p className="font-semibold">${calculateTotal()}</p>
              </div>
              <div className="flex justify-between">
                <p className="text-gray-600">Delivery</p>
                <p className="font-semibold">FREE</p>
              </div>
              <div className="text-gray-600">
                <p>Punjab, Pakistan</p>
              </div>
            </div>

            <div className="border-t pt-4 mt-4">
              <div className="flex justify-between">
                <h2 className="text-xl font-bold">Total</h2>
                <p className="text-xl font-bold">${calculateTotal()}</p>
              </div>
            </div>

            <button
              onClick={handleCheckout}
              disabled={checkoutLoading || cartItems.length === 0}
              className="w-full mt-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              {checkoutLoading ? "Processing..." : "Checkout"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}