import React, { useEffect, useState } from "react";
import Product from "../cards/Product";

export default function Products() {
  const [products, setProducts] = useState([]);

  // Fetch products from the backend
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch("http://localhost:8000/api/products/"); // Correct URL
        if (!response.ok) {
          const errorText = await response.text(); // Log the response as text
          console.error("Server response:", errorText);
          throw new Error("Failed to fetch products");
        }
        const data = await response.json();
        setProducts(data); // Update state with fetched products
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };

    fetchProducts();
  }, []);

  return (
    <div className="mx-auto max-w-7xl p-8">
      <div className="flex flex-col md:flex-row gap-10">
        {/* Sidebar with categories */}
        <div className="md:w-1/4 space-y-5">
          <h1 className="font-semibold text-lg underline">All Products</h1>
          <ul className="space-y-3">
            <li className="cursor-pointer hover:text-gray-500">Sunglasses</li>
            <li className="cursor-pointer hover:text-gray-500">Eyewear</li>
            <li className="cursor-pointer hover:text-gray-500">Prescription</li>
            <li className="cursor-pointer hover:text-gray-500">Transition</li>
            <li className="cursor-pointer hover:text-gray-500">Lens</li>
          </ul>
        </div>

        {/* Product Grid */}
        <div className="md:w-3/4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {/* Map through products and render a Product component for each */}
            {products.map((product) => (
              <Product key={product.id} product={product} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}