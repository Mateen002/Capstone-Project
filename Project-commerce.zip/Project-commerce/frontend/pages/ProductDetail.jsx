import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

export default function ProductDetail() {
  const { id } = useParams(); // Get the product ID from the URL
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  // Fetch product details from the backend
  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await fetch(`http://localhost:8000/api/products/${id}/`);
        if (!response.ok) {
          throw new Error("Failed to fetch product details");
        }
        const data = await response.json();
        setProduct(data); // Set the product details
      } catch (error) {
        console.error("Error fetching product details:", error);
        setError("Failed to load product details");
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id]);

  // Handle quantity increment
  const incrementQuantity = () => {
    setQuantity((prev) => prev + 1);
  };

  // Handle quantity decrement
  const decrementQuantity = () => {
    setQuantity((prev) => (prev > 1 ? prev - 1 : 1));
  };

  // Handle adding the product to the cart
  const handleAddToCart = async () => {
    try {
      const token = localStorage.getItem("access_token"); // Get the JWT token
      if (!token) {
        navigate("/login"); // Redirect to login page if the user is not authenticated
        return;
      }

      const response = await fetch("http://localhost:8000/api/cart/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`, // Include the token in the request
        },
        body: JSON.stringify({
          product: product.id, // Product ID
          quantity: quantity, // Selected quantity
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to add product to cart");
      }

      alert("Product added to cart successfully!"); // Show a success message
      navigate("/cart"); // Redirect to the cart page
    } catch (error) {
      console.error("Error adding product to cart:", error);
      setError("Failed to add product to cart");
    }
  };

  if (loading) {
    return <div>Loading...</div>; // Show a loading state while fetching data
  }

  if (error) {
    return <div>Error: {error}</div>; // Show an error message if something went wrong
  }

  if (!product) {
    return <div>No product found.</div>; // Handle case where product is null
  }

  return (
    <div className="mx-auto max-w-7xl mb-10">
      <div className="md:mx-9 mx-5 flex flex-col md:flex-row gap-8">
        {/* Product Image */}
        <div>
          <img
            src={
              product.image
                ? `http://localhost:8000${product.image}` // Use the full URL for the product image
                : "/1.webp" // Fallback image (ensure this exists in your public folder)
            }
            className="max-h-[500px] w-auto md:max-w-[350px] object-cover rounded-lg" // Your CSS
            alt={product.name}
          />
        </div>

        {/* Product Info - Aligned to the right */}
        <div className="flex-1 space-y-5">
          <div className="space-y-4">
            <h1 className="text-3xl font-medium">{product.name}</h1>
            <h2 className="font-semibold">Rs {product.price}</h2>
            <p>{product.description}</p>
            <div className="flex items-center justify-center border w-[120px] px-2 py-2 rounded">
              <button
                onClick={decrementQuantity}
                className="px-2 py-1 rounded bg-white hover:bg-gray-300"
              >
                -
              </button>
              <p className="text-lg font-medium mx-2">{quantity}</p>
              <button
                onClick={incrementQuantity}
                className="px-2 py-1 rounded hover:bg-gray-300"
              >
                +
              </button>
            </div>
          </div>

          {/* Buttons */}
          <div className="flex flex-col md:flex-row gap-3">
            <button
              onClick={handleAddToCart}
              className="bg-amber-200 py-2 w-full border rounded-lg hover:bg-white"
            >
              Add to Cart
            </button>
            <button className="bg-white py-2 w-full border rounded-lg hover:bg-amber-200">
              Buy Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}