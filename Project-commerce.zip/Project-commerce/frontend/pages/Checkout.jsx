import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

export default function Checkout() {
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const location = useLocation();
  const navigate = useNavigate();

  // Fetch order details from the backend
  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const token = localStorage.getItem("access_token"); // Get the JWT token
        if (!token) {
          navigate("/login"); // Redirect to login page if the user is not authenticated
          return;
        }

        const orderId = location.state?.orderId; // Get the order ID from the location state
        if (!orderId) {
          throw new Error("Order ID not found");
        }

        const response = await fetch(`http://localhost:8000/api/orders/${orderId}/`, {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the request
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch order details");
        }

        const data = await response.json();
        setOrder(data); // Set the order details
      } catch (error) {
        console.error("Error fetching order details:", error);
        setError("Failed to load order details");
      } finally {
        setLoading(false);
      }
    };

    fetchOrder();
  }, [location.state, navigate]);

  if (loading) {
    return <div className="text-center py-10">Loading...</div>; // Show a loading state while fetching data
  }

  if (error) {
    return <div className="text-center py-10 text-red-500">Error: {error}</div>; // Show an error message if something went wrong
  }

  return (
    <div className="mx-auto max-w-7xl mb-10 px-4 sm:px-6 lg:px-8">
      <div className="bg-white p-8 rounded-lg shadow-sm">
        <h1 className="text-3xl font-bold mb-6">Order Confirmation</h1>
        {order ? (
          <div className="space-y-6">
            <div className="border-b pb-4">
              <h2 className="text-xl font-semibold">Order ID: {order.id}</h2>
              <p className="text-gray-600">Thank you for your purchase!</p>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between">
                <p className="text-gray-600">Shipping Address</p>
                <p className="font-semibold">{order.shipping_address}</p>
              </div>
              <div className="flex justify-between">
                <p className="text-gray-600">Payment Method</p>
                <p className="font-semibold">{order.payment_method}</p>
              </div>
              <div className="flex justify-between">
                <p className="text-gray-600">Total Price</p>
                <p className="font-semibold">${order.total_price}</p>
              </div>
            </div>

            <button
              onClick={() => navigate("/")}
              className="w-full mt-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
            >
              Continue Shopping
            </button>
          </div>
        ) : (
          <p className="text-gray-600">No order details found.</p>
        )}
      </div>
    </div>
  );
}