import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from '../components/NavBar';

import Home from '../pages/Home';
import Products from '../pages/Products';
import ProductDetail from '../pages/ProductDetail';
import Footer from '../components/Footer';
import Login from "../pages/Login";
import Register from "../pages/Register";
import Cart from "../pages/Cart";

import ProtectedRoute from "../pages/ProtectedRoute";
import Checkout from '../pages/Checkout';
import AddProduct from '../pages/AddProduct';
import AboutPage from '../pages/AboutPage';
function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route element={<ProtectedRoute />}></Route>
        <Route path="/products" element={<Products />} />
        <Route path="/product/:id" element={<ProductDetail />} /> {/* Dynamic route for product details */}
        <Route path="/cart" element={<Cart/>} />
        <Route path="/checkout" element={<Checkout/>} />
        <Route path="/add-product" element={<AddProduct/>} />
        <Route path="/about" element={<AboutPage/>} />

        {/* <Route element={<ProtectedRoute adminOnly={true} />}>
          <Route path="/add-product" element={<AddProduct />} />
        </Route> */}


      </Routes>
      <Footer/>

    </Router>
  );
}

export default App;
