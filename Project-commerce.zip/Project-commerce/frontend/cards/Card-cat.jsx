export default function Card_cat (props) {
    return(
        <>
        <div className={` text-center bg-gray-100 rounded-2xl p-5.5 w-full md:h-full md:w-100 space-y-5  ${props.bg}`}>
            <div className="h-90 md:h-100 md:w-full overflow-hidden">
              <img
              // object-cover
                src={props.img}
                className="w-full h-full  rounded-2xl"
                alt="Category"
              />
            </div>
            <div>
              <button className="border py-2 px-14 text-4xl rounded-lg">{props.text}</button>
            </div>
          </div>
        </>
    )
}