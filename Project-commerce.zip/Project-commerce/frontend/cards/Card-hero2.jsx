export default function Card_2(props){
    return(
        <>
        <div
  style={{ backgroundImage: `url(${props.img})` }}
  className="bg-contain bg-center  bg-no-repeat h-150 w-100 md:h-90 md:w-95 flex-1.5 rounded-2xl flex-shrink-0 md:flex-shrink snap-center"
>
</div>


        </>
    )
}