import { useNavigate } from "react-router-dom";

export default function Product({ product }) {
  const navigate = useNavigate();

  // Navigate to the product detail page when the image is clicked
  const handleProductClick = () => {
    navigate(`/product/${product.id}`); // Navigate to the product detail page with the product ID
  };

  // Construct the image URL
  const getImageUrl = (image) => {
    if (!image) return "/1.webp"; // Fallback image
    if (image.startsWith("http")) return image; // Full URL already provided
    return `http://localhost:8000${image}`; // Prepend base URL for relative paths
  };

  return (
    <div className="flex flex-col items-center text-center p-4 rounded-lg shadow-md">
      {/* Product Image - Clickable */}
      <img
        src={getImageUrl(product.image)} // Use the constructed image URL
        className="h-full w-full object-cover rounded-lg cursor-pointer" // Your original CSS
        alt={product.name}
        onClick={handleProductClick} // Add onClick handler
      />

      {/* Product Name */}
      <p className="mt-3 text-lg font-medium">{product.name}</p>

      {/* Price & Button */}
      <div className="mt-2 space-y-2">
        <h2 className="text-xl font-semibold">Rs {product.price}</h2>
      </div>
    </div>
  );
}