from rest_framework import generics
from .models import Product, Cart, Order, User
from .serializers import ProductSerializer, CartSerializer, UserSerializer
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAdminUser
from .models import Order
from .serializers import OrderSerializer


class ProductList(generics.ListCreateAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class ProductDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class ProductCreateView(generics.CreateAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [IsAdminUser] # Only admins can create products
    
class CartList(generics.ListCreateAPIView):
    serializer_class = CartSerializer
    # permission_classes = [IsAuthenticated]

    def get_queryset(self):
        # Use select_related to fetch related product details in a single query
        return Cart.objects.filter(user=self.request.user).select_related('product')
    
    def perform_create(self, serializer):
        serializer.save(user=self.request.user)
    
    def create(self, request, *args, **kwargs):
        print("Request Data:", request.data)  # Log the request data
        return super().create(request, *args, **kwargs)

class CartDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = CartSerializer
    # permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Cart.objects.filter(user=self.request.user)
    
    def patch(self, request, *args, **kwargs):
        # Handle the PATCH request for updating quantity
        cart_item = self.get_object()
        new_quantity = request.data.get('quantity')
        if new_quantity is not None:
            cart_item.quantity = new_quantity
            cart_item.save()
            return Response(self.get_serializer(cart_item).data, status=status.HTTP_200_OK)
        return Response({"detail": "Invalid data"}, status=status.HTTP_400_BAD_REQUEST)

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    
    


class CheckoutView(APIView):
    # permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        cart_items = Cart.objects.filter(user=user)

        # Debugging: Log the request data
        print("Request Data:", request.data)

        if not cart_items.exists():
            return Response({"error": "Cart is empty."}, status=status.HTTP_400_BAD_REQUEST)

        total_price = request.data.get('total_price')
        shipping_address = request.data.get('shipping_address')
        payment_method = request.data.get('payment_method')

        # Validate required fields
        if not total_price:
            return Response({"error": "Total price is required."}, status=status.HTTP_400_BAD_REQUEST)
        if not shipping_address:
            return Response({"error": "Shipping address is required."}, status=status.HTTP_400_BAD_REQUEST)
        if not payment_method:
            return Response({"error": "Payment method is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            total_price = float(total_price)  # Convert to float
        except ValueError:
            return Response({"error": "Invalid total price format."}, status=status.HTTP_400_BAD_REQUEST)

        # Create the order
        order = Order.objects.create(
            user=user,
            shipping_address=shipping_address,
            payment_method=payment_method,
            total_price=total_price,
        )

        # Clear the cart after checkout
        cart_items.delete()

        return Response({"message": "Checkout successful!", "order_id": order.id}, status=status.HTTP_201_CREATED)
    
class OrderDetailView(generics.RetrieveAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
    # permission_classes = [IsAuthenticated]  # Ensure only authenticated users can access this view