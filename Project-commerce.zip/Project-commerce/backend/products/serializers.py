from rest_framework import serializers
from .models import Cart, Product, Order
from django.contrib.auth.models import User



class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'

class CartSerializer(serializers.ModelSerializer):
    product = serializers.PrimaryKeyRelatedField(
        queryset=Product.objects.all(), write_only=True
    )  # ✅ Accepts product ID when creating a cart item

    product_details = ProductSerializer(source='product', read_only=True)  
    # ✅ Returns full product details when retrieving the cart
    
    user = serializers.PrimaryKeyRelatedField(read_only=True)

    class Meta:
        model = Cart
        fields = ['id', 'product', 'product_details', 'quantity', 'user']  # Include 'user' field

    def validate(self, data):
        if not data.get("product"):
            raise serializers.ValidationError("Product ID is required.")
        return data
    
    def validate_quantity(self, value):
        if value < 1:
            raise serializers.ValidationError("Quantity must be at least 1.")
        return value
    

class UserSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['username', 'password', 'email']

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            password=validated_data['password'],
            email=validated_data.get('email', '')
        )
        
        return user
    
    def validate(self, data):
        print("Validating data:", data)  # Debugging
        return data

    
class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = '__all__'    
        
        
