from django.urls import path
from .views import ProductList, ProductDetail, CartList, CartDetail,RegisterView, CheckoutView,ProductCreateView, OrderDetailView
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('products/', ProductList.as_view(), name='product-list'),
    path('products/create/', ProductCreateView.as_view(), name='product-create'),

    path('products/<int:pk>/', ProductDetail.as_view(), name='product-detail'),
    path('cart/', CartList.as_view(), name='cart-list'),
    path('cart/<int:pk>/', CartDetail.as_view(), name='cart-detail'),
    path('register/', RegisterView.as_view(), name='register'),
    path('checkout/', CheckoutView.as_view(), name='checkout'),

    path('orders/<int:pk>/', OrderDetailView.as_view(), name='order-detail'),  # Add this line


    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)